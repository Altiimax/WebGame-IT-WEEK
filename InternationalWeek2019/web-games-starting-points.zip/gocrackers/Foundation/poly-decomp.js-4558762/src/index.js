module.exports = {
    Polygon : require("./Polygon"),
    Point : require("./Point"),
};
