YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "Line",
        "Point",
        "Polygon",
        "Scalar"
    ],
    "modules": [],
    "allModules": []
} };
});