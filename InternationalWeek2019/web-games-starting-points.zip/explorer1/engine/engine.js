
//
// Engine script loader
//

function include(url) {
  
  var sc = document.createElement('script');
  sc.src = url;
  document.head.appendChild(sc);
}

include('engine/matter_js/matter.js');
include('engine/gl-matrix/gl-matrix-min.js');
include('engine/system.js');
include('engine/util.js');
include('engine/clock.js');
include('engine/sprite.js');
include('engine/SpriteSheet.js');
include('engine/AnimationSequence.js');
include('engine/player.js');
include('engine/projectile.js');
include('engine/pickups.js');
include('engine/background.js');
include('engine/player_states.js');
include('config.js');
include('engine/stages/game_stage.js');
include('engine/characters/character_ufo.js');
include('engine/CollisionModel.js');
